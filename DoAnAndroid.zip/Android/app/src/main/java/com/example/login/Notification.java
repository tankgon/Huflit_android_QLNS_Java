package com.example.login;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Objects;

public class Notification implements Serializable {
    String Tital;
    String Des;

    public Notification(String tital, String des) {
        Tital = tital;
        Des = des;
    }

    public static ArrayList<Notification> initData(){
        ArrayList<Notification> tmp = new ArrayList<>();
        tmp.add(new Notification("Nghỉ lễ 30/4 và 1/5", "Các nhân viên được nghỉ từ ngày 30/4 đến ngày 2/5/2022"));
        tmp.add(new Notification("Đi làm lại sau khi nghỉ lễ", "Các nhân viên bắt đầu đi làm lại từ ngày 3/5/2022"));
        return tmp;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Notification)) return false;
        Notification that = (Notification) o;
        return Objects.equals(Tital, that.Tital) && Objects.equals(Des, that.Des);
    }

    @Override
    public int hashCode() {
        return Objects.hash(Tital, Des);
    }
}
