package com.example.login;

import android.content.Context;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Objects;

public class NhanVien implements Serializable {
    String Name;
    String SoDienThoai;
    int Avata;

    public NhanVien(String name, String soDienThoai) {
        Name = name;
        SoDienThoai = soDienThoai;
    }

    public NhanVien(String name, String soDienThoai, int avata) {
        Name = name;
        SoDienThoai = soDienThoai;
        Avata = avata;
    }

    public static ArrayList<NhanVien> initData(Context context){
        ArrayList<NhanVien> tmp = new ArrayList<>();
        tmp.add(new NhanVien("Hồ Tấn Hùng", "038 299 1361", R.drawable.hung));
        tmp.add(new NhanVien("Hồ Tấn Hùng", "038 299 1361", R.drawable.hung));
        return tmp;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof NhanVien)) return false;
        NhanVien nhanVien = (NhanVien) o;
        return Avata == nhanVien.Avata && Objects.equals(Name, nhanVien.Name) && Objects.equals(SoDienThoai, nhanVien.SoDienThoai);
    }

    @Override
    public int hashCode() {
        return Objects.hash(Name, SoDienThoai, Avata);
    }
}
