package com.example.login;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class NhanVienAdapter extends RecyclerView.Adapter<NhanVienAdapter.NhanVienVH> {

    ArrayList<NhanVien> arrayList;
    Listener listener;

    public NhanVienAdapter(ArrayList<NhanVien> arrayList, Listener listener) {
        this.arrayList = arrayList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public NhanVienVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_nhanvien, parent, false);
        NhanVienAdapter.NhanVienVH nhanVienVH = new NhanVienAdapter.NhanVienVH(view);
        return nhanVienVH;
    }


    @Override
    public void onBindViewHolder(@NonNull NhanVienVH holder, int position) {
        NhanVien nhanVien = arrayList.get(position);
        holder.imgAvata.setImageResource(nhanVien.Avata);
        holder.txtNameNV.setText(nhanVien.Name);
        holder.txtSDTNV.setText(nhanVien.SoDienThoai);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.onClick(nhanVien);
            }
        });
    }


    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    class NhanVienVH extends RecyclerView.ViewHolder{
        TextView txtNameNV, txtSDTNV;
        ImageView imgAvata;
        public NhanVienVH(@NonNull View itemView) {
            super(itemView);

            txtNameNV = itemView.findViewById(R.id.txt_NameNV);
            txtSDTNV = itemView.findViewById(R.id.txt_SDTNV);
            imgAvata = itemView.findViewById(R.id.img_AvataNhanVien);
        }
    }

    public interface Listener {
        void onClick(NhanVien nhanVien);
    }
}
