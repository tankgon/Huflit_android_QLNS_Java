package com.example.login;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class ThongTinNhanVienActivity extends AppCompatActivity {
    EditText edtHoTen, edtGioiTinh, edtNgaySinh, edtPhongBan, edtChucVu, edtEmail, edtSDT, edtDiaChi;
    Button btnUpdate, btnDelete;
    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thong_tin_nhan_vien);

        edtHoTen = findViewById(R.id.edtHoTen);
        edtGioiTinh = findViewById(R.id.edtGioiTinh);
        edtNgaySinh = findViewById(R.id.edtNgaySinh);
        edtPhongBan = findViewById(R.id.edtPhongBanlNV);
        edtChucVu = findViewById(R.id.edtChucVuNV);
        edtEmail = findViewById(R.id.edtEmailNV);
        edtSDT = findViewById(R.id.edtSDT);
        edtDiaChi = findViewById(R.id.edtDiaChi);

        btnUpdate = findViewById(R.id.btnUpdateNhanVien);
        btnDelete = findViewById(R.id.btnXoaNhanVien);

        toolbar = findViewById(R.id.toolbarThongTinNV);
    }
}