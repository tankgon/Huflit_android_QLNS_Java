package com.example.login;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class NotificationAdapter extends RecyclerView.Adapter<NotificationAdapter.NotificationVH> {

    ArrayList<Notification> arrayList;

    Listener listener;

    public NotificationAdapter(ArrayList<Notification> arrayList, Listener listener) {
        this.arrayList = arrayList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public NotificationVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_item_noti, parent, false);
        NotificationVH notificationVH = new NotificationVH(view);
        return notificationVH;
    }


    @Override
    public void onBindViewHolder(@NonNull NotificationVH holder, int position) {

        Notification notification = arrayList.get(position);
        holder.txtTital.setText(notification.Tital);
        holder.txtDes.setText(notification.Des);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.onClick(notification);
            }
        });
    }


    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    class NotificationVH extends RecyclerView.ViewHolder {
        TextView txtTital, txtDes;
        public NotificationVH(@NonNull View itemView) {
            super(itemView);

            txtTital = itemView.findViewById(R.id.txtTieuDe);
            txtDes = itemView.findViewById(R.id.txtTitalDetal);
        }
    }

    interface Listener{
        void onClick(Notification notification);
    }

}
