package com.example.login;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.material.textfield.TextInputEditText;

public class AddNotificationActivity extends AppCompatActivity {

    TextInputEditText txtInputTitalNoti, txtInputDesNoti;
    Button btnOK;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_notification);

        txtInputTitalNoti = findViewById(R.id.txt_InputTitalNotification);
        txtInputDesNoti = findViewById(R.id.txt_InputDesNotification);

        btnOK = findViewById(R.id.btn_OkAddNotification);
        btnOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AddNotificationActivity.this, NotificationFragment.class);
                startActivity(intent);
                finish();
            }
        });
    }
}